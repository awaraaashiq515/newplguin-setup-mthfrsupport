<?php
namespace MTHFR\Core\Report;

class Exception extends \Exception
{
}