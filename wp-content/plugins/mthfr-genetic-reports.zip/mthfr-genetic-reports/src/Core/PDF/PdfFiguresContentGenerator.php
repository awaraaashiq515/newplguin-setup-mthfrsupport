<?php namespace MTHFR\PDF; if (!defined('ABSPATH')) exit; class PdfFiguresContentGenerator {}
